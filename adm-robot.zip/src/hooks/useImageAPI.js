import { useState, useEffect, useCallback } from 'react';

const API_BASE = "http://localhost:3000"; 

// Imágenes de simulación que el Front-end usaría
const MOCK_IMAGES = [
    { 
        url: "https://placehold.co/800x600/7C5CE4/ffffff?text=Flecha+Izquierda", 
        description: "Instrucción: Flecha izquierda detectada", 
        type: "sign", 
        ts: Date.now() - 3600000 
    },
    { 
        url: "https://placehold.co/800x600/21C07A/ffffff?text=QR+Analizado", 
        description: "Código QR detectado (Destino: Almacén B)", 
        type: "qr", 
        ts: Date.now() - 1800000 
    },
    { 
        url: "https://placehold.co/800x600/171D31/ffffff?text=Estante+Vacío", 
        description: "Objeto: Estante vacío (Revisión de inventario)", 
        type: "other", 
        ts: Date.now() - 60000 
    },
];

export const useImageAPI = (robotId) => {
    const [images, setImages] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const fetchImages = useCallback(async () => {
        if (!robotId) {
            // Si no hay robot ID, limpiamos y terminamos.
            setImages([]);
            return;
        }

        setIsLoading(true);
        setError(null);
        
        try {
            // SIMULACIÓN DE LLAMADA A API
            // En una aplicación real, aquí harías:
            // const res = await fetch(`${API_BASE}/api/images/${robotId}`);
            // if (!res.ok) throw new Error('Error al cargar imágenes de la API.');
            // const data = await res.json();
            // setImages(data.sort((a, b) => b.ts - a.ts));

            // Retraso simulado para ver el estado de carga
            await new Promise(resolve => setTimeout(resolve, 600)); 

            // Devolver las imágenes de simulación, filtradas por un ID ficticio
            const simulatedImages = MOCK_IMAGES.map((img, index) => ({
                ...img,
                id: `img-${robotId}-${index}`,
                // Simulación de que el robot R2 tiene más imágenes recientes
                ts: img.ts + (robotId === 'R2' ? 500000 : 0)
            })).sort((a, b) => b.ts - a.ts);


            setImages(simulatedImages);

        } catch (e) {
            console.error("Fetch Images Error:", e);
            setError("No se pudieron cargar las imágenes históricas.");
        } finally {
            setIsLoading(false);
        }
    }, [robotId]); // Depende solo de robotId

    useEffect(() => {
        // Al montar o cambiar el robotId, ejecutamos la función
        fetchImages();
    }, [fetchImages]); // Depende de fetchImages (que a su vez depende de robotId)

    // Se retorna el objeto del hook
    return { images, isLoading, error, refetch: fetchImages };
};