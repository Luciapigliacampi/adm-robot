// src/pages/RobotSelector.jsx
import React, { useEffect, useState } from "react";
import { Zap, CornerDownRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { fetchRobotsFromApi } from "../services/robots";
import { aliasName, setAliasDbId } from "../config/robotAliases";


export default function RobotSelector() {
  const navigate = useNavigate();
  const [robots, setRobots] = useState([]);

  useEffect(() => {
    (async () => {
      const real = await fetchRobotsFromApi();

      // Tomamos el primer robot real (si existe) y lo mapeamos a R1
      const list = [];
      if (real.length > 0) {
        const r1 = real[0];
        setAliasDbId("R1", r1.dbId);
        list.push({
          alias: "R1",
          name: aliasName.R1,
          status: r1.status ?? "En espera",
          battery: r1.battery ?? 92,
          dbId: r1.dbId,
          fake: false,
        });
      } else {
        // Si no hay ninguno en API pero tenés VITE_ROBOT_ID, fetchRobotsFromApi ya lo puso
        // y entra por acá igualmente como real[0]. Si tampoco hay, mostramos igualmente R1 fake.
        list.push({
          alias: "R1",
          name: aliasName.R1,
          status: "En espera",
          battery: 92,
          dbId: null,
          fake: true,
        });
      }

      // Agregamos dos robots “falsos”
      list.push({
        alias: "R2",
        name: aliasName.R2,
        status: "En ruta",
        battery: 65,
        dbId: null,
        fake: true,
  });
      list.push({
        alias: "R3",
        name: aliasName.R3,
        status: "Inactivo",
        battery: 40,
        dbId: null,
        fake: true,
      });

      setRobots(list);
    })();
  }, []);

  const handleRobotSelect = (alias) => {
    navigate(`/dashboard/${alias}`);
  };

  return (
    <main className="main selector-page">
      <div className="card title-card">
        <h1>Selección de Robot</h1>
        <p className="muted">Selecciona el robot para acceder al panel de administración y telemetría.</p>
      </div>

      <div className="robot-grid">
        {robots.map((robot) => (
          <div
            key={robot.alias}
            className="card robot-card"
            onClick={() => handleRobotSelect(robot.alias)}
          >
            <Zap size={36} color="var(--accent)" />
            <h2>{robot.name}</h2>

            <div className="status-row">
              <span className={
                "status-badge " +
                (robot.status?.includes("ruta")
                  ? "ok"
                  : robot.status?.includes("Inactivo")
                  ? "err"
                  : "warn")
              }>
                {String(robot.status || "—").toUpperCase()}
              </span>
              <span className="battery-info">Batería: {robot.battery ?? "—"}%</span>
            </div>

            <CornerDownRight size={24} color="var(--accent)" className="select-icon" />
          </div>
        ))}
      </div>
    </main>
  );
}
